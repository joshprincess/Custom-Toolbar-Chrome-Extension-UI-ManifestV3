/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* Universal injection - runs on ALL domains (MAIN world)      */
/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */

console.log('🚀 Injector+ Universal Mode Active on this page!');

/* ======================================================== */
/* FAKE TOOLBAR (MAIN WORLD)                               */
/* ======================================================== */
(function injectFakeToolbar() {
    const TOOLBAR_ID = 'injector-plus-fake-toolbar';

    function createToolbar() {
        if (document.getElementById(TOOLBAR_ID)) return;

        const toolbarHTML = `
            <div id="${TOOLBAR_ID}" style="position:fixed;top:0;left:0;width:100%;height:52px;background:#202124;color:#e8eaed;display:flex;align-items:center;padding:0 12px;box-shadow:0 2px 6px rgba(0,0,0,0.4);z-index:2147483647;font-family:system-ui,sans-serif;user-select:none;box-sizing:border-box;border-bottom:1px solid #3c4043;">
                <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:0;">
                    <div style="background:#3c4043;padding:4px 14px;border-radius:6px 6px 0 0;font-size:12px;white-space:nowrap;">New Tab</div>
                    <div style="background:#292a2d;padding:4px 14px;border-radius:6px 6px 0 0;font-size:12px;opacity:0.7;white-space:nowrap;">+ New</div>
                </div>
                <div style="flex:2.2;background:#292a2d;margin:0 16px;padding:7px 14px;border-radius:20px;display:flex;align-items:center;gap:8px;font-size:13px;color:#bdc1c6;min-width:0;">
                    <span style="color:#4ade80;">🔒</span>
                    <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">https://example.com/injector-plus</span>
                </div>
                <div style="display:flex;align-items:center;gap:12px;flex-shrink:0;">
                    <button id="toolbar-reload" style="background:none;border:none;color:#bdc1c6;cursor:pointer;font-size:16px;padding:4px;">⟳</button>
                    <button id="toolbar-close" style="background:none;border:none;color:#bdc1c6;cursor:pointer;font-size:18px;padding:4px 6px;">✕</button>
                </div>
            </div>
        `;

        const container = document.createElement('div');
        container.innerHTML = toolbarHTML.trim();
        const toolbar = container.firstElementChild;
        
        if (toolbar) {
            document.documentElement.appendChild(toolbar);

            // Button handlers
            toolbar.querySelector('#toolbar-close').onclick = () => toolbar.remove();
            toolbar.querySelector('#toolbar-reload').onclick = () => location.reload();
        }
    }

    function removeToolbar() {
        const tb = document.getElementById(TOOLBAR_ID);
        if (tb) tb.remove();
    }

    // Listen for control messages from isolated world
    window.addEventListener('message', (event) => {
        if (event.source !== window || !event.data.type) return;

        if (event.data.type === "INJECTOR_PLUS_INIT" || event.data.type === "INJECTOR_PLUS_TOGGLE") {
            if (event.data.enabled) {
                createToolbar();
            } else {
                removeToolbar();
            }
        }
    });

    console.log('✅ Fake toolbar system ready (waiting for init from isolated script)');
})();

/* ======================================================== */
/* ORIGINAL SPOOFING CODE (your previous content)         */
/* ======================================================== */
injector.injectInlineJs(`
    console.log('🚀 Injector+ Universal script starting...');

    // === PASTE YOUR FULL ORIGINAL SPOOFING CODE HERE ===
    // (the big block with cleanupWindowProps, UA spoof, hardware, canvas, audio, WebRTC, etc.)
    // Keep everything exactly as it was before this update.
`);

/* ======================================================== */
/* ORIGINAL SPOOFING CODE (kept intact)                    */
/* ======================================================== */
injector.injectInlineJs(`
    console.log('🚀 Injector+ Universal script starting...');

    // Remove unwanted window properties
    (function cleanupWindowProps() {
        const badProps = ['_ic_event_super_props', '__do_not_use_me_isNodeRendered', 'ADBLOCK_DETECTED', '_rollbarWrappedError', '_rollbarInitialized'];
        badProps.forEach(prop => {
            if (prop in window) delete window[prop];
        });
        if (window.user_channel_props) delete window.user_channel_props.user_channel_1;
        console.log('✅ Unwanted window properties cleaned');
    })();

    // Spoof language
    Object.defineProperty(navigator, 'language', { get: () => 'en-US', configurable: true });
    Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'], configurable: true });

    // UA spoof
    const chromeVersion = '149.0.0.0';
    const newUA = \`Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/\${chromeVersion} Safari/537.36\`;
    Object.defineProperty(navigator, 'userAgent', { get: () => newUA, configurable: true });
    Object.defineProperty(navigator, 'appVersion', { get: () => newUA, configurable: true });

    // Page always visible
    (function spoofVisibility() {
        Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
        Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
        const origAdd = document.addEventListener;
        document.addEventListener = function(type, listener, options) {
            if (type === 'visibilitychange') return;
            return origAdd.apply(this, arguments);
        };
        console.log('✅ Page always appears visible');
    })();

    // CSS protection
    injector.injectInternalCss(\`
        @media (max-device-width: 99999px) { }
        @media (max-device-height: 99999px) { }
    \`);

    // 1. RICH HARDWARE
    (function spoofRichHardware() {
        try {
            Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 256, configurable: true });
        } catch(e) {}
        if ('deviceMemory' in navigator) {
            try {
                Object.defineProperty(navigator, 'deviceMemory', { get: () => 16, configurable: true });
            } catch(e) {}
        }
        console.log('✅ Rich Hardware Spoofed');
    })();

    // 2a. CANVAS
    (function spoofCanvas() {
        const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
        CanvasRenderingContext2D.prototype.getImageData = function(sx, sy, sw, sh, settings) {
            const imageData = origGetImageData.apply(this, arguments);
            const data = imageData.data;
            const noise = 5;
            for (let i = 0; i < data.length; i += 4) {
                data[i] = Math.max(0, Math.min(255, data[i] + (Math.random() * noise * 2 - noise)));
                data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + (Math.random() * noise * 2 - noise)));
                data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + (Math.random() * noise * 2 - noise)));
            }
            return imageData;
        };
        const origFillText = CanvasRenderingContext2D.prototype.fillText;
        CanvasRenderingContext2D.prototype.fillText = function(text, x, y, maxWidth) {
            const offsetX = (Math.random() - 0.5) * 1.5;
            const offsetY = (Math.random() - 0.5) * 1.5;
            return origFillText.call(this, text, x + offsetX, y + offsetY, maxWidth);
        };
        console.log('✅ Canvas protection active');
    })();

    // 2b. WINDOWS 11 FONT WHITELIST + LIGHT STRING NOISE
    (function whitelistWin11FontsAndStringNoise() {
        'use strict';
        console.log('🔤 Starting Windows 11 font whitelist + light string noise...');

        const DEFAULT = 'Segoe UI, system-ui, sans-serif';
        const baseFonts = ["auto", "inherit", "default", "!important", "sans-serif", "serif", "monospace"];
        const FontWhiteList = ["arial","arial black","bahnschrift","calibri","calibri light","cambria","cambria math","candara","cascadia code","cascadia mono","comic sans ms","consolas","constantia","corbel","courier new","franklin gothic medium","gabriola","gadugi","georgia","impact","ink free","leelawadee ui","lucida console","lucida sans unicode","malgun gothic","marlett","microsoft sans serif","palatino linotype","segoe fluent icons","segoe mdl2 assets","segoe print","segoe script","segoe ui","segoe ui variable","segoe ui black","segoe ui emoji","segoe ui historic","segoe ui symbol","sitka","sylfaen","symbol","tahoma","times new roman","trebuchet ms","verdana","webdings","wingdings","ebrima","microsoft himalaya","microsoft jhenghei","microsoft jhenghei ui","microsoft phags pa","microsoft tai le","microsoft yahei","microsoft yi baiti","mingliu-extb","mongolian baiti","ms gothic","myanmar text","nirmala ui","nsimsun","simsun","yu gothic"].map(f => f.toLowerCase());

        baseFonts.push(...FontWhiteList);

        function getAllowedFontFamily(family) {
            if (!family) return DEFAULT;
            const fonts = family.replace(/["']/g, '').split(',');
            const allowed = fonts.filter(font => {
                if (!font?.trim()) return false;
                const norm = font.trim().toLowerCase();
                return baseFonts.some(allowed => norm === allowed || norm.startsWith(allowed)) || document.fonts?.check?.(\`12px \${norm}\`);
            });
            return allowed.length ? allowed.map(f => {
                const t = f.trim();
                return t.includes(' ') ? \`'\${t}'\` : t;
            }).join(", ") : DEFAULT;
        }

        // Font overrides (simplified)
        const originalSetProperty = CSSStyleDeclaration.prototype.setProperty;
        CSSStyleDeclaration.prototype.setProperty = function(key, val) {
            if (key.toLowerCase() === 'font-family') {
                return originalSetProperty.call(this, key, getAllowedFontFamily(val));
            }
            return originalSetProperty.call(this, key, val);
        };

        // Light String Noise
        (function addLightStringNoise() {
            const origCharAt = String.prototype.charAt;
            const origCharCodeAt = String.prototype.charCodeAt;

            String.prototype.charAt = function(index) {
                const val = origCharAt.apply(this, arguments);
                const idx = Number(index);
                if ([0,1,35,45,50,60,65].includes(idx) && Math.random() > 0.65) {
                    return String.fromCharCode(65 + Math.floor(Math.random() * 26));
                }
                return val;
            };

            String.prototype.charCodeAt = function(index) {
                let code = origCharCodeAt.apply(this, arguments);
                const idx = Number(index);
                if ([0,1,35,45,50,60,65].includes(idx) && Math.random() > 0.6) {
                    code += (Math.random() > 0.5 ? 1 : -1);
                }
                return code;
            };
            console.log('✅ Light string noise active');
        })();

        injector.injectInternalCss(\`* { font-family: Segoe UI, system-ui, sans-serif !important; }\`);
        console.log('✅ Windows 11 font whitelist active');
    })();

    // 3. Enhanced RTX 4090 Ti SUPER WebGL
    (function spoofWebGL() {
        const fakeVendor = "Google Inc.";
        const fakeRenderer = "ANGLE (NVIDIA, NVIDIA GeForce RTX 4090 Ti SUPER Direct3D12 vs_6_0 ps_6_0, D3D12)";
        const unmaskedVendor = "NVIDIA Corporation";
        const unmaskedRenderer = "NVIDIA GeForce RTX 4090 Ti SUPER/PCIe/SSE2";

        function hookWebGL() {
            const origGetContext = HTMLCanvasElement.prototype.getContext;
            HTMLCanvasElement.prototype.getContext = function(type, attrs) {
                if (!type || !type.includes('webgl')) return origGetContext.apply(this, arguments);
                const gl = origGetContext.apply(this, arguments);
                if (!gl) return gl;

                const origGetParameter = gl.getParameter.bind(gl);
                gl.getParameter = function(param) {
                    switch(param) {
                        case 0x1F00: case 37445: return param === 37445 ? unmaskedVendor : fakeVendor;
                        case 0x1F01: case 37446: return param === 37446 ? unmaskedRenderer : fakeRenderer;
                        case 0x0D33: return 32768;
                        case 0x0D32: return 16384;
                        default: return origGetParameter(param);
                    }
                };
                return gl;
            };
        }
        hookWebGL();
        window.addEventListener('load', hookWebGL);
        setInterval(hookWebGL, 800);
        console.log('✅ Enhanced RTX 4090 Ti SUPER WebGL spoof active');
    })();

    // 4. Strong iframe.contentWindow protection
    (function protectIframesAndContentWindow() {
        const spoofedUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36';
        const originalCreateElement = Document.prototype.createElement;
        Document.prototype.createElement = function(tagName) {
            const element = originalCreateElement.call(this, tagName);
            if (tagName.toLowerCase() === 'iframe') {
                Object.defineProperty(element, 'contentWindow', {
                    get: function() {
                        const cw = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'contentWindow').get.call(this);
                        if (cw && cw.navigator) {
                            Object.defineProperty(cw.navigator, 'userAgent', { get: () => spoofedUA, configurable: true });
                        }
                        return cw;
                    },
                    configurable: true
                });
            }
            return element;
        };
        console.log('✅ iframe.contentWindow protection strengthened');
    })();

    console.log('✅ All spoofs activated! Rich PC + strong anti-fingerprinting ready.');
`);