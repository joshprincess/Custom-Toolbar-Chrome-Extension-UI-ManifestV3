// background.js

// Existing imports...
importScripts('core/inject-to.js');
importScripts('core/functions.js');
importScripts('core/extension.js');
importScripts('core/injection-process.js');

chrome.action.onClicked.addListener((tab) => {
    if (!tab?.id) return;

    chrome.storage.local.get(['showToolbar'], (result) => {
        const newState = !(result.showToolbar !== false);

        chrome.storage.local.set({ showToolbar: newState });

        chrome.tabs.sendMessage(tab.id, {
            action: "toggleToolbar",
            enabled: newState
        }).catch(err => {
            console.warn("Content script not ready, skipping for now", err);
        });
    });
});