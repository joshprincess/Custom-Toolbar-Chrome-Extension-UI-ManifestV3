// core/content-script.js
// This runs in the ISOLATED world so chrome.* APIs are available

console.log('🚀 Injector+ Isolated Content Script Loaded');

// Forward messages to MAIN world for toolbar control
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "toggleToolbar") {
        window.postMessage({
            type: "INJECTOR_PLUS_TOGGLE",
            enabled: message.enabled
        }, "*");
        
        sendResponse({ success: true });
    }
    return true;
});

// Send initial state on page load
chrome.storage.local.get(['showToolbar'], (result) => {
    window.postMessage({
        type: "INJECTOR_PLUS_INIT",
        enabled: result.showToolbar !== false
    }, "*");
});