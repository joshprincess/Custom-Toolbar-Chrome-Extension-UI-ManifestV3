/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* Perform actions for the `first install` of the extension */
/* 'install' = Extension was just installed ••••••••••••••• */
/* 'update' = Extension was updated or reloaded ••••••••••• */
/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
chrome.runtime.onInstalled.addListener(details => {
    if (details.reason === 'install') {
        chrome.storage.local.set({ state: true, showToolbar: true });
        updateExtensionIcon();
    } else if (details.reason === 'update') {
        updateExtensionIcon();
    }
});

/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* Perform actions for when the Google Chrome starts (launched) */
/* •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
chrome.runtime.onStartup.addListener(() => {
    updateExtensionIcon();
});

/* ••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* Perform actions for when the extension turned off and turned on by user */
/* ••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
updateExtensionIcon();