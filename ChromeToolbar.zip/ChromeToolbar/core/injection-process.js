/* ••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* Content Script + document_start is now handling injection.         */
/* This file kept minimal for the toggle / state logic.               */
/* ••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */

// Optional: keep the toggle functionality
chrome.action.onClicked.addListener(() => {
    changeExtensionIcon();
});
/* ••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/* UNIVERSAL + EARLY INJECTION - Clean Version                       */
/* Executes early (on 'loading') for better WebGL spoofing           */
/* ••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••• */
/*
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'loading' || changeInfo.status === 'complete') {
        chrome.storage.local.get('state', (result) => {
            if (result && result.state) {
                if (tab?.url && 
                    !tab.url.startsWith('chrome://') && 
                    !tab.url.startsWith('chrome-extension://')) {
                    
                    chrome.scripting.executeScript({
                        target: { tabId: tabId, allFrames: true },
                        world: 'MAIN',
                        files: [
                            'core/injection-types.js',
                            'inject-to/universal.js'
                        ]
                    }).catch(err => {
                        // Ignore common frame destruction errors
                        if (!err.message?.includes('Frame with ID') && 
                            !err.message?.includes('was removed')) {
                            console.warn('[Injector+] Injection error:', err.message);
                        }
                    });
                }
            }
        });
    }
});
*/